﻿(function($) {
    $.osharp = $.osharp || { version: 1.0 };
    $.osharp.data = $.osharp.data || {};
})(jQuery);
(function($) {
    $.osharp.data.demo = {
        operateTypes: [{ id: "0", text: "查询" }, { id: "10", text: "新建" }, { id: "20", text: "更新" }, { id: "30", text: "删除" }],
        functionTypes: [{ id: "0", text: "匿名访问" }, { id: "1", text: "登录访问" }, { id: "2", text: "角色访问" }]
    };
})(jQuery);