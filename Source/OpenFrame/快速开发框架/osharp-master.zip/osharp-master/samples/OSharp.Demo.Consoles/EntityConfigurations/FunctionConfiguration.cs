﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using OSharp.Data.Entity;
using OSharp.Core.Security;


namespace OSharp.Demo.Consoles.EntityConfigurations
{
    public class FunctionConfiguration : EntityConfigurationBase<Function, Guid>
    {
    }
}
