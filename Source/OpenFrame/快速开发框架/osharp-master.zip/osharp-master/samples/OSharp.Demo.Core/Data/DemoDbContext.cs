﻿// -----------------------------------------------------------------------
//  <copyright file="DemoDbContext.cs" company="OSharp开源团队">
//      Copyright (c) 2014-2015 OSharp. All rights reserved.
//  </copyright>
//  <last-editor>郭明锋</last-editor>
//  <last-date>2015-07-01 2:02</last-date>
// -----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using OSharp.Data.Entity;


namespace OSharp.Demo.Data
{
    public class DemoDbContext : DbContextBase<DemoDbContext>
    { }
}