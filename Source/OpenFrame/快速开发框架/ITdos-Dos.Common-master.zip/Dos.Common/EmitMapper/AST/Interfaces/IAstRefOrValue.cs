﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EmitMapper.AST.Interfaces
{
    interface IAstRefOrValue: IAstStackItem
    {
    }
}