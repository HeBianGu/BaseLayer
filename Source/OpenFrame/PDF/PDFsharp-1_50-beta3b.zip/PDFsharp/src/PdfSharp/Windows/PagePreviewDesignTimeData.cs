﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace PdfSharp.Windows
{
  public class PagePreviewDesignTimeData
  {
    public double CanvasWidth
    {
      get { return 210; }
      set { }
    }

    public double CanvasHeight
    {
      get { return 297; }
      set { }
    }
  }
}
